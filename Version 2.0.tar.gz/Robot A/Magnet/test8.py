from MagnetControl import Magnet

import pigpio



iman = Magnet(27)

iman.turn(True)
