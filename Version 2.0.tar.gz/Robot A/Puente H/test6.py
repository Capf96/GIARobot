from grua import Grua
from time import sleep

grua = Grua(5, 26)

grua.subir()

#sleep(1)

#grua.parar()
