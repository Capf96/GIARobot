from MagnetControl import Magnet

iman = Magnet(27)
