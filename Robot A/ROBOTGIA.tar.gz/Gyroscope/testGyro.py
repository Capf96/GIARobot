from IMU import *
imu = IMU()
imu.getData(1)

